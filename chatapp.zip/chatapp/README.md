Nickolas Di Domenico: 101083325

Tiago Sa: 101054051

To run app:

> npm install

> npm start

browser: localhost:3000 or whichever port terminal says is listening on


To send private message to a user in the app do the following:

/w [username] [message]
