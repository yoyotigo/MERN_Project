import React, { Component } from 'react';

class Admin extends Component {
    state = {  }
    render() { 
        return (
            <div>
                Admin!
            </div>
          );
    }
}
 
export default Admin;