import React, { Component } from 'react';
import Chat from "./components/Chat";
import Login from "./components/Login";
import Admin from "./components/Admin";
import { BrowserRouter, Route, Switch, Link} from "react-router-dom";

class App extends Component {
  render() {
    return (
      <BrowserRouter>
      <li><Link to="/">Chat</Link></li>
      <li><Link to="/login">Login</Link></li>
      <Route>
      <Switch>
        <Route path="/" component={Chat} exact/>
        <Route path="/login" component={Login}/>
        <Route path="/admin" component={Admin}/>
        <Route component={Error}/>
      </Switch>
      </Route>
      </BrowserRouter>
    );
  }
}

export default App;